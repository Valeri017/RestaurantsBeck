from django.db import models
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey

# Create your models here.

#1 Category
#2 Product
#restaurants
# CartProduct
# Cart
# Order
#Customer
#specification
User = get_user_model()

class Category(models.Model):
    name = models.CharField( max_length=255, verbose_name = 'Name Category')
    slug = models.SlugField(unique=True)

    def __str__(self):
        return self.name

class Product(models.Model):

    class Meta:
        abstract = True
    category = models.ForeignKey(Category, max_length=255, verbose_name = 'Category',
                                 on_delete=models.CASCADE)
    title = models.CharField(max_length=255, verbose_name = 'Product')
    slug = slug = models.SlugField(unique=True)
    image = models.ImageField(verbose_name='image')
    description = models.TextField()
    price = models.DecimalField(max_digits = 9, decimal_places = 2,
                                verbose_name = 'price' )

    def __str__(self):
        return self.title

class Customer(models.Model):

    user = models.ForeignKey(User, verbose_name = 'User', on_delete=models.CASCADE)
    phone = models.CharField(max_length=20,verbose_name = 'phone number')
    addres = models.CharField(max_length=200, verbose_name = 'addres')
    email = models.CharField(max_length = 100, verbose_name = 'email')
    def __str__(self):
        return 'Customer: {} {}'.format(self.user.first_name, self.user.last_name)


class CartProduct(models.Model):
    user = models.ForeignKey('Customer', verbose_name = 'user',
    on_delete = models.CASCADE)
    cart = models.ForeignKey('Cart',verbose_name = 'Basket', on_delete=models.CASCADE,
                             related_name='related_products' )
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type','object_id')
    qty = models.PositiveIntegerField(default = 1 )
    final_price = models.DecimalField(max_digits = 9, decimal_places = 2,
                                      verbose_name = 'total amount')

    def __str__(self):
        return 'Product: {} (for basket)'.format(self.product.title)

class Cart(models.Model):

    owner = models.ForeignKey('Customer', verbose_name='owner',
                               on_delete = models.CASCADE)
    products = models.ManyToManyField(CartProduct, blank = True,
                                      related_name='related_cart')
    total_products = models.PositiveIntegerField(default = 0)
    final_price = models.DecimalField(max_digits = 9, decimal_places = 2,
                                      verbose_name = 'total amount')
    def __str__(self):
        return str(self.id)

class FastFood(Product):
    meet = models.CharField(max_length=200, verbose_name = 'meet')
    chees = models.CharField(max_length=200, verbose_name = 'chees')
    vegetables = models.TextField()
    def __str__(self):
        return f"{self.category.name}:{self.title}"#.format(self.category.name, self.title)

class Drink(Product):
    alcohol = models.CharField(max_length=200, verbose_name = 'Alcohol Fortress')
    valume =  models.CharField(max_length=200, verbose_name = 'Beverage volume')
    def __str__(self):
        return f"{self.category.name}:{self.title}"#.format(self.category.name, self.title)

#TODO Написать таблицы возможных категорий блюд
'''class Specification(models.Model):

    content_type = models.ForeignKey(ContentType, on_delete = models.CASCADE)
    object_id = models.PositiveIntegerField()
    name = models.CharField(max_length = 255, verbose_name = 'Cooking products')

    def __str__(self):
        return 'Cooking products'.format(self.name)'''
